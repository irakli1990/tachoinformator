import { StatusChip } from './StatusChip';
import { formatDate } from '../shared/formatters';

export function UploadsTable({ uploads, onSelect }) {
  if (!uploads.length) {
    return (
      <tr>
        <td colspan="5">
          <div class="empty">
            <svg viewBox="0 0 24 24" fill="var(--gray-300)">
              <path d="M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 14H4V8l8 5 8-5v10zm-8-7L4 6h16l-8 5z"/>
            </svg>
            <p>Brak zgłoszeń</p>
          </div>
        </td>
      </tr>
    );
  }

  return uploads.map(u => (
    <tr key={u.id} onClick={() => onSelect(u)}>
      <td>
        <div style="font-weight:500">{u.client_name}</div>
        <div class="td-sub">#{u.id.slice(0, 8)}</div>
      </td>
      <td>{u.email}</td>
      <td>{(u.files ?? []).filter(Boolean).length} plik(ów)</td>
      <td><StatusChip status={u.status} /></td>
      <td class="td-mono">{formatDate(u.created_at)}</td>
    </tr>
  ));
}
