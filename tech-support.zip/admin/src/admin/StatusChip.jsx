const LABELS = {
  completed: 'Ukończony',
  pending:   'Oczekuje',
  partial:   'Częściowy',
  failed:    'Błąd',
};

export function StatusChip({ status }) {
  return (
    <span class={`chip ${status}`}>
      <span class="chip-dot" />
      {LABELS[status] ?? status}
    </span>
  );
}
