export function Stats({ uploads }) {
  const total   = uploads.length;
  const done    = uploads.filter(u => u.status === 'completed').length;
  const pending = uploads.filter(u => ['pending', 'partial'].includes(u.status)).length;

  return (
    <div class="stats">
      <div class="stat-card accent">
        <div class="stat-label">Łącznie uploadów</div>
        <div class="stat-value">{total || '—'}</div>
        <div class="stat-sub">wszystkie zgłoszenia</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Ukończone</div>
        <div class="stat-value">{total ? done : '—'}</div>
        <div class="stat-sub">status: completed</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Oczekujące</div>
        <div class="stat-value">{total ? pending : '—'}</div>
        <div class="stat-sub">status: pending / partial</div>
      </div>
    </div>
  );
}
