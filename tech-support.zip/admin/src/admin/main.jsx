import { render } from 'preact';
import { AdminPage } from './AdminPage';
import '../shared/global.css';

render(<AdminPage />, document.getElementById('app'));
