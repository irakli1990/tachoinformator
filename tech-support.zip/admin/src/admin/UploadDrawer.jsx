import { StatusChip } from './StatusChip';
import { formatSize, formatDate } from '../shared/formatters';
import { fetchDownloadUrl, deleteUpload } from '../shared/api';

export function UploadDrawer({ upload, token, onClose, onDeleted }) {
  const open = upload != null;

  async function handleDownload(fileId, e) {
    e.stopPropagation();
    try {
      const { downloadUrl } = await fetchDownloadUrl(token, upload.id, fileId);
      const a = document.createElement('a');
      a.href = downloadUrl;
      a.download = '';
      a.click();
    } catch (err) {
      alert('Błąd pobierania: ' + err.message);
    }
  }

  async function handleDelete() {
    if (!confirm('Czy na pewno chcesz usunąć to zgłoszenie i pliki z S3?')) return;
    try {
      await deleteUpload(token, upload.id);
      onDeleted(upload.id);
      onClose();
    } catch (err) {
      alert('Błąd usuwania: ' + err.message);
    }
  }

  return (
    <>
      <div class={`drawer-overlay${open ? ' open' : ''}`} onClick={onClose} />
      <div class={`drawer${open ? ' open' : ''}`}>
        {upload && (
          <>
            <div class="drawer-head">
              <div>
                <div class="drawer-client-name">{upload.client_name}</div>
                <div class="drawer-meta">{upload.email} · {formatDate(upload.created_at)}</div>
              </div>
              <button class="drawer-close" onClick={onClose}>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
                  <line x1="18" y1="6" x2="6" y2="18"/>
                  <line x1="6" y1="6" x2="18" y2="18"/>
                </svg>
              </button>
            </div>

            <div class="drawer-body">
              <div class="drawer-section">
                <div class="drawer-section-title">Dane kontaktowe</div>
                <div class="info-row"><span class="info-row-label">Imię / firma</span><span class="info-row-val">{upload.client_name}</span></div>
                <div class="info-row"><span class="info-row-label">Email</span><span class="info-row-val">{upload.email}</span></div>
                <div class="info-row"><span class="info-row-label">Status</span><span class="info-row-val"><StatusChip status={upload.status} /></span></div>
                <div class="info-row"><span class="info-row-label">Data</span><span class="info-row-val">{formatDate(upload.created_at)}</span></div>
              </div>

              <div class="drawer-section">
                <div class="drawer-section-title">Opis problemu</div>
                <div class="desc-box">{upload.description || '(brak opisu)'}</div>
              </div>

              <div class="drawer-section">
                <div class="drawer-section-title">Pliki</div>
                {(upload.files ?? []).filter(Boolean).length === 0 ? (
                  <p class="no-files">Brak plików</p>
                ) : (
                  (upload.files ?? []).filter(Boolean).map(f => (
                    <div class="file-row" key={f.id}>
                      <div class="file-row-icon">
                        <svg viewBox="0 0 24 24" fill="var(--red)">
                          <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6zm4 18H6V4h7v5h5v11z"/>
                        </svg>
                      </div>
                      <div class="file-row-info">
                        <div class="file-row-name" title={f.name}>{f.name}</div>
                        <div class="file-row-size">{formatSize(f.size)} · <StatusChip status={f.status ?? 'pending'} /></div>
                      </div>
                      <button class="btn-download" onClick={(e) => handleDownload(f.id, e)}>
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
                          <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                          <polyline points="7 10 12 15 17 10"/>
                          <line x1="12" y1="15" x2="12" y2="3"/>
                        </svg>
                        Pobierz
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>

            <div class="drawer-footer">
              <button class="btn btn-danger" onClick={handleDelete}>
                <svg viewBox="0 0 24 24" fill="currentColor">
                  <path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/>
                </svg>
                Usuń zgłoszenie
              </button>
            </div>
          </>
        )}
      </div>
    </>
  );
}
