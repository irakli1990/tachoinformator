import { useSignal, useComputed, effect } from '@preact/signals';
import { Stats } from './Stats';
import { UploadsTable } from './UploadsTable';
import { UploadDrawer } from './UploadDrawer';
import { fetchUploads } from '../shared/api';
import './admin.css';

function getToken() {
  const stored = localStorage.getItem('admin_token');
  if (stored) return stored;
  const entered = prompt('Podaj token admina:') ?? '';
  localStorage.setItem('admin_token', entered);
  return entered;
}

export function AdminPage() {
  const token    = useSignal(getToken());
  const uploads  = useSignal([]);
  const selected = useSignal(null);
  const query    = useSignal('');
  const error    = useSignal('');
  const loading  = useSignal(false);

  const filtered = useComputed(() => {
    const q = query.value.toLowerCase();
    if (!q) return uploads.value;
    return uploads.value.filter(u =>
      u.client_name?.toLowerCase().includes(q) ||
      u.email?.toLowerCase().includes(q) ||
      u.description?.toLowerCase().includes(q)
    );
  });

  async function load() {
    loading.value = true;
    error.value   = '';
    try {
      const data = await fetchUploads(token.value);
      uploads.value = data.data ?? [];
    } catch (err) {
      error.value = err.message;
    } finally {
      loading.value = false;
    }
  }

  function handleDeleted(id) {
    uploads.value = uploads.value.filter(u => u.id !== id);
  }

  // Initial load
  effect(() => { load(); });

  return (
    <div class="layout">
      {/* Sidebar */}
      <aside>
        <div class="sidebar-logo">
          <div class="logo-box">
            <svg viewBox="0 0 24 24" fill="white">
              <path d="M19.35 10.04A7.49 7.49 0 0 0 12 4C9.11 4 6.6 5.64 5.35 8.04A5.994 5.994 0 0 0 0 14c0 3.31 2.69 6 6 6h13c2.76 0 5-2.24 5-5 0-2.64-2.05-4.78-4.65-4.96zM14 13v4h-4v-4H7l5-5 5 5h-3z"/>
            </svg>
          </div>
          <div class="logo-name">Support<span>Upload</span></div>
        </div>
        <nav>
          <div class="nav-section-label">Menu</div>
          <a class="nav-item active" href="#">
            <svg viewBox="0 0 24 24" fill="currentColor">
              <path d="M3 13h8V3H3v10zm0 8h8v-6H3v6zm10 0h8V11h-8v10zm0-18v6h8V3h-8z"/>
            </svg>
            Uploadsy
            <span class="badge">{uploads.value.length}</span>
          </a>
        </nav>
      </aside>

      {/* Content */}
      <div class="content">
        <div class="topbar">
          <div class="topbar-title">Przesłane pliki</div>
          <div class="topbar-actions">
            <button class="btn btn-ghost" onClick={load} disabled={loading.value}>
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
                <polyline points="23 4 23 10 17 10"/>
                <path d="M20.49 15a9 9 0 1 1-.08-6.8"/>
              </svg>
              Odśwież
            </button>
          </div>
        </div>

        <div class="page-body">
          <Stats uploads={uploads.value} />

          <div class="table-card">
            <div class="table-header">
              <div class="table-title">Lista zgłoszeń</div>
              <input
                class="search"
                type="text"
                placeholder="Szukaj (imię, email…)"
                value={query.value}
                onInput={(e) => { query.value = e.target.value; }}
              />
            </div>

            {error.value ? (
              <div class="table-error">Błąd ładowania: {error.value}</div>
            ) : (
              <table>
                <thead>
                  <tr>
                    <th>Klient</th>
                    <th>Email</th>
                    <th>Pliki</th>
                    <th>Status</th>
                    <th>Data</th>
                  </tr>
                </thead>
                <tbody>
                  <UploadsTable
                    uploads={filtered.value}
                    onSelect={(u) => { selected.value = u; }}
                  />
                </tbody>
              </table>
            )}
          </div>
        </div>
      </div>

      <UploadDrawer
        upload={selected.value}
        token={token.value}
        onClose={() => { selected.value = null; }}
        onDeleted={handleDeleted}
      />
    </div>
  );
}
